const router = require('express').Router();
const database = require("../database/database");
class HelloWorldRouteHandler{

	static routerHandler(){
		
		router.get('/', function (req, res) {
		  //res.send('Birds home page')
		  const db2 = new database();
		  console.log(req.query.user);
		  const readParams = {collectionName:"users", criteria : {name:req.query.user}, projection : {name:1,_id:0}};
		  readParams.callback = function(data){
		  	//res.send("database too called");

		  	res.send(data)
		  }
		  //db2.create();
		  db2.read(readParams);
		})
		

		router.post('/', function (req, res) {
		  const db2 = new database();
		  console.log(req);
			const obj = req.body;

		const insertParams={collectionName:"users"};
		console.log(insertParams);
		insertParams.payload=obj;
		 insertParams.callback = function(data){
		  	//res.send("database too called");

		  	res.send(data)
		  }
				  //db2.create();
				  db2.create(insertParams);
		})


		return router;
	}

}

module.exports = HelloWorldRouteHandler;
