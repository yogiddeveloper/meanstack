const express = require('express');
const cors = require('cors');
const app = express();
app.use(cors());
const bodyParser  =  require("body-parser");

/*app.get('/', function(req, res){
  res.send('hello yogesh');
});*/


//
//const helloRouteHandler=require("./server/helloworld/HelloWorldRouteHandler");
//app.use("/hello",helloRouteHandler.routerHandler());

//app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());


const helloRouteHandler=require("./server/helloworld/HelloWorldRouteHandler");
app.use("/hello",helloRouteHandler.routerHandler());

/*app.get('/login/:user/:password',function(req,res){
  var user_name=req.params.user;
  var password=req.params.password;
  console.log("User name = "+user_name+", password is "+password);
  res.end("yes");
});



app.get('/login',function(req,res){
  var user_name=req.query.user;
  var password=req.query.password;
  console.log("User name = "+user_name+", password is "+password);
  res.end("yes");
});*/


//helloRouteHandler.routerHandler();

console.log("server started");
app.listen(3000);